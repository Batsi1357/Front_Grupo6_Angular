import { Component } from '@angular/core';

@Component({
  selector: 'app-evaluacion-list',
  standalone: false,
  templateUrl: './evaluacion-list.html',
  styleUrl: './evaluacion-list.css',
})
export class EvaluacionList {

}
