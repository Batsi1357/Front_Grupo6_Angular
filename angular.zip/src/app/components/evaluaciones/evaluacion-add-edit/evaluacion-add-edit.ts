import { Component } from '@angular/core';

@Component({
  selector: 'app-evaluacion-add-edit',
  standalone: false,
  templateUrl: './evaluacion-add-edit.html',
  styleUrl: './evaluacion-add-edit.css',
})
export class EvaluacionAddEdit {

}
