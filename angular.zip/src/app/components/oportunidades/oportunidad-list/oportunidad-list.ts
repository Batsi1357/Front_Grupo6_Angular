import { Component } from '@angular/core';

@Component({
  selector: 'app-oportunidad-list',
  standalone: false,
  templateUrl: './oportunidad-list.html',
  styleUrl: './oportunidad-list.css',
})
export class OportunidadList {

}
