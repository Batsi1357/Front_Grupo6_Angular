import { Component } from '@angular/core';

@Component({
  selector: 'app-oportunidad-add-edit',
  standalone: false,
  templateUrl: './oportunidad-add-edit.html',
  styleUrl: './oportunidad-add-edit.css',
})
export class OportunidadAddEdit {

}
