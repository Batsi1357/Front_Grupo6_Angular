import { Component } from '@angular/core';

@Component({
  selector: 'app-rol-list',
  standalone: false,
  templateUrl: './rol-list.html',
  styleUrl: './rol-list.css',
})
export class RolList {

}
