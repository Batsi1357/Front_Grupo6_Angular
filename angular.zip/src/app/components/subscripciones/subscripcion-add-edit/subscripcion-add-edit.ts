import { Component } from '@angular/core';

@Component({
  selector: 'app-subscripcion-add-edit',
  standalone: false,
  templateUrl: './subscripcion-add-edit.html',
  styleUrl: './subscripcion-add-edit.css',
})
export class SubscripcionAddEdit {

}
