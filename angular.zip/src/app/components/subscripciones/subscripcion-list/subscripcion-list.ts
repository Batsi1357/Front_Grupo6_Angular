import { Component } from '@angular/core';

@Component({
  selector: 'app-subscripcion-list',
  standalone: false,
  templateUrl: './subscripcion-list.html',
  styleUrl: './subscripcion-list.css',
})
export class SubscripcionList {

}
