import { Component } from '@angular/core';

@Component({
  selector: 'app-clase-list',
  standalone: false,
  templateUrl: './clase-list.html',
  styleUrl: './clase-list.css',
})
export class ClaseList {

}
