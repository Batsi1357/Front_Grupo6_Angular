import { Component } from '@angular/core';

@Component({
  selector: 'app-clase-add-edit',
  standalone: false,
  templateUrl: './clase-add-edit.html',
  styleUrl: './clase-add-edit.css',
})
export class ClaseAddEdit {

}
