import { Component } from '@angular/core';

@Component({
  selector: 'app-unidad-list',
  standalone: false,
  templateUrl: './unidad-list.html',
  styleUrl: './unidad-list.css',
})
export class UnidadList {

}
