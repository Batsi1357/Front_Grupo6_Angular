import { Component } from '@angular/core';

@Component({
  selector: 'app-respuesta-add-edit',
  standalone: false,
  templateUrl: './respuesta-add-edit.html',
  styleUrl: './respuesta-add-edit.css',
})
export class RespuestaAddEdit {

}
