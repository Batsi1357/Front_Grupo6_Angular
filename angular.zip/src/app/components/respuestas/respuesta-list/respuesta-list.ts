import { Component } from '@angular/core';

@Component({
  selector: 'app-respuesta-list',
  standalone: false,
  templateUrl: './respuesta-list.html',
  styleUrl: './respuesta-list.css',
})
export class RespuestaList {

}
