import { Component } from '@angular/core';

@Component({
  selector: 'app-orden-subscripcion-list',
  standalone: false,
  templateUrl: './orden-subscripcion-list.html',
  styleUrl: './orden-subscripcion-list.css',
})
export class OrdenSubscripcionList {

}
