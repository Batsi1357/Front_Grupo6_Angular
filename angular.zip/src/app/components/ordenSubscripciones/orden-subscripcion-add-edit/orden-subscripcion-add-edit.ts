import { Component } from '@angular/core';

@Component({
  selector: 'app-orden-subscripcion-add-edit',
  standalone: false,
  templateUrl: './orden-subscripcion-add-edit.html',
  styleUrl: './orden-subscripcion-add-edit.css',
})
export class OrdenSubscripcionAddEdit {

}
