import { Component } from '@angular/core';

@Component({
  selector: 'app-pregunta-add-edit',
  standalone: false,
  templateUrl: './pregunta-add-edit.html',
  styleUrl: './pregunta-add-edit.css',
})
export class PreguntaAddEdit {

}
