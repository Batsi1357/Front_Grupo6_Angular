import { Component } from '@angular/core';

@Component({
  selector: 'app-pregunta-list',
  standalone: false,
  templateUrl: './pregunta-list.html',
  styleUrl: './pregunta-list.css',
})
export class PreguntaList {

}
