import { Component } from '@angular/core';

@Component({
  selector: 'app-cliente-list',
  standalone: false,
  templateUrl: './cliente-list.html',
  styleUrl: './cliente-list.css',
})
export class ClienteList {

}
