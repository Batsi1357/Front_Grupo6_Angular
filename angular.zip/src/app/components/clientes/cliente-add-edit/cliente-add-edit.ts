import { Component } from '@angular/core';

@Component({
  selector: 'app-cliente-add-edit',
  standalone: false,
  templateUrl: './cliente-add-edit.html',
  styleUrl: './cliente-add-edit.css',
})
export class ClienteAddEdit {

}
