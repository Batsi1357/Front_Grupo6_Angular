export interface clase
{
     idClase:number,
    ClasePersonalizada:string
}