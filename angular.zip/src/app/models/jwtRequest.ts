export interface JwtRequestModel{

   username:string,
   password:string


}