export interface unidad
{
    idUnidad:number,
    titulo:string,
    descripcion:string,
    nivel:number,
    categoria:string,
    duracion:number

}