export interface evaluacion
{
    idEvaluacion:number,
    titulo:string,
    descripcion:string,
    fechaInicio:string,
    duracion:number
}

