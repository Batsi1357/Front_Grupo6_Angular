export interface subscripcion
{
    idSubscripcion:number,
    Nombre:string,
    Descripcion:string,
    Precio:number
}