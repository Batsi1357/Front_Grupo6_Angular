export interface usuario
{
    idUsuario:number,
    Username:string,
    Password:string,
    activo:string
}