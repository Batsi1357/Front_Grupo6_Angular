export interface respuesta
{
    idRespuesta:number,
    Texto:string,
    Respuesta:string
}