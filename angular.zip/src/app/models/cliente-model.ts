export interface cliente
{
    idCliente:number,
    Nombre:string,
    Apellido:string,
    Direccion:string,
    Celular:string,
    email:string,
    edad:number
}