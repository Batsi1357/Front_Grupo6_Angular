export interface oportunidad
{
    idOportunidad:number,
    Intento:number,
    FechaInicio:string
}

