export interface pregunta
{
    idPregunta:number,
    Enunciado:string,
    Tipo:string,
    Puntaje:number
}