export interface JwtResponseModel {

    token:string
}