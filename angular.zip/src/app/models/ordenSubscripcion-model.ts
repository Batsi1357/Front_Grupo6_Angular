export interface ordenSubscripcion
{
    idOrdenSubscripcion:number,
    Estado:string,
    FechaInicio:string,
    FechaFin:string
}