export interface rol {

    idrol:number,
    nombre:string 

}